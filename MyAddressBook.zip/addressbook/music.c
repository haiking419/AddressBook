#include <string.h>
#include <windows.h>
#pragma comment(lib,"winmm.lib")	//��������ͷ�ļ���

#include "function.h"

void MusicPlayer(void)
{
	switch(MusicMenu())
	{
	case '1':
		music("F:\\lost.wav");
		break;
	case '2':
		musicplay("BlueStream.wav");
		break;
	case '3':
		musicclose();
		break;
	case '0':
		return;
	default :
		break;
	}
	
}

char MusicMenu(void)
{
	char sel[5]="";
	system("cls");
	printf("------------MsicMenu----------\n");
	printf("1.F:\\lost.wav\n");
	printf("2.BlueStream.wav\n");
	printf("3.close music\n");
	printf("0.return\n");
	printf("Please select :");
	gets(sel);
	while(strlen(sel)!=1&&(sel[0]<'0'||sel[0]>3))
	{
		printf("Illegal input,please try again :");
		gets(sel);
	}
	return sel[0];
}

void music(char path[20])
{
//	char name[22]="";
	PlaySound(NULL, NULL, SND_FILENAME | SND_ASYNC | SND_LOOP);
//	strcpy(name,path);
//	PlaySound("F:\\lost.wav", NULL, SND_FILENAME | SND_ASYNC | SND_LOOP);
	PlaySound(path, NULL, SND_FILENAME | SND_ASYNC | SND_LOOP);
	//������wav��ʽ������ 
//	Sleep(3*1000);
//	PlaySound(NULL, NULL, SND_FILENAME | SND_ASYNC | SND_LOOP);
}
void musicplay(char path[20])
{
	PlaySound(path, NULL, SND_FILENAME | SND_ASYNC | SND_LOOP);
}
void musicclose(void)
{
	PlaySound(NULL, NULL, SND_FILENAME | SND_ASYNC | SND_LOOP);
}