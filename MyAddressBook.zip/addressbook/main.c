#include "function.h"

#include "data.h"

int main(void)
{
	PRECORD head = NULL;
	InitList(&head);
	head->next = GetRecordFromFile();
	music("F:\\lost.wav");
	while(1)
	{
		switch( MainMenu() )
		{
		case '1':
			AddRecord(head);
			break;
		case '2':
			BrowserRecord(head);
			break;
		case '3':
			DeleteRecord(head);
			break;
		case '4':
			SearchRecord(head);
			break;
		case '5':
			ModifyRecord(head);
			break;
		case '6':
			SortRecord(head);
			break;
		case '7':
			ConserveRecord(head);
			break;
		case '8':
			Help();
			break;
		case '0':
			SaveRecord(head);
			DestoryList(head);
			exit(0);
		default :
			break;
		}
		
	}
	
	return 0;
}