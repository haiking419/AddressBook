#ifndef _FUNCTION_H_
#define _FUNCTION_H_


#include <stdio.h>
#include <stdlib.h>

#include "data.h"

BOOL InitList(RECORD** head);

PRECORD GetRecordFromFile(void);

char MainMenu(void);

int AddRecord(PRECORD head);

void BrowserRecord(PRECORD head);

void SearchRecord(PRECORD head);
char SearchMenu();
void SearchByName(PRECORD head);
void SearchByTel(PRECORD head);

BOOL SearchByNameResult(PRECORD head,char* pName);

BOOL MenuSelError(char* sel);

void SaveRecord(PRECORD head);
void DestoryList(PRECORD head);

void ModifyRecord(PRECORD head);
char ModifyMenu1(void);
void ModifyByName(PRECORD head);
void ModifyByTel(PRECORD head);

void DeleteRecord(PRECORD head);
char DeleteMenu(void);
void DeleteAll(PRECORD head);
void DeleteByName(PRECORD head);

void SortRecord(PRECORD head);
char SortMenu(void);
void SortByName(PRECORD head);
void SortByTel(PRECORD head);


void ConserveRecord(PRECORD head);
void Help(void);

void music(char path[20]);
void musicplay(char path[20]);
void musicclose(void);


#endif